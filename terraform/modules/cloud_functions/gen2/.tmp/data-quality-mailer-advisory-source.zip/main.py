import os
import smtplib, ssl
import logging
import markdown
import functions_framework
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from flask import Request

# Configure logging
logging.basicConfig(level=logging.INFO)

# Triggered from a HTTP request (Cloud Scheduler)
@functions_framework.http
def send_email(request: Request):
    """
    Function to send a static email about data quality.
    Logs each step and handles potential errors.
    """
    # Check the request method
    if request.method != 'POST':
        logging.error(f"Invalid request method: {request.method}")
        return 'Invalid request method', 405  # Method Not Allowed

    port = 465  # SSL port for Mailgun
    smtp_server = "smtp.eu.mailgun.org"
    sender_email = "noreply@data.southpole.com"
    receiver_email = "advisory@southpole.com"
    password = os.getenv("MAILGUN_PWD")

    # Logging start of email process
    logging.info(f"Preparing to send email to {receiver_email}")

    # Prepare the email content
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = "Your Outstanding Data Quality Issues"
        msg['From'] = formataddr(('Data Quality Team', sender_email))
        msg['To'] = receiver_email

        # Load and convert HTML template to markdown
        logging.info("Reading and converting email template.")
        with open('template.html', 'r') as file:
            template = file.read()

        # Convert markdown to HTML
        text = markdown.markdown(template)
        message = MIMEText(text, "html")
        msg.attach(message)
    except Exception as e:
        logging.error(f"Error preparing email content: {e}")
        return 'Error preparing email content', 500  # Internal Server Error

    # Send the email via Mailgun's SMTP
    try:
        logging.info(f"Connecting to SMTP server {smtp_server}")
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
        logging.info(f"Email successfully sent to {receiver_email}")
        return 'Email sent successfully', 200  # Success
    except Exception as e:
        logging.error(f"Error sending email: {e}")
        return 'Error sending email', 500  # Internal Server Error

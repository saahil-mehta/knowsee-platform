# Data Quality Mailer - Advisory

Cloud Function Gen2 that sends data quality email notifications to the advisory team on alternate weeks.

## Configuration

- **Runtime**: Python 3.11
- **Entry Point**: `send_email`
- **Trigger**: HTTP (Cloud Scheduler)
- **Region**: europe-west1

## Environment Variables

- `LOG_EXECUTION_ID`: Enable execution ID logging
- `MAILGUN_PWD`: Mailgun password (from Secret Manager)

## Recipients

- `advisory@southpole.com`

## Deployment

Deployed via Terraform. Source code is automatically zipped and uploaded to GCS bucket on `terraform apply`.
